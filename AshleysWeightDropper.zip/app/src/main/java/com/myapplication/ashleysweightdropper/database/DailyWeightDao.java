package com.myapplication.ashleysweightdropper.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import com.myapplication.ashleysweightdropper.model.DailyWeight;

import java.util.Date;
import java.util.List;

@Dao
public interface DailyWeightDao {

    //gets record from users
    @Query("SELECT * FROM dailyWeights ORDER BY date")
    public List<DailyWeight> getDailyWeights();

    //Orders weights record by date for current user
    @Query("SELECT * FROM dailyWeights WHERE username = :input ORDER BY date ASC")
    public List<DailyWeight> getDailyWeightsOfUser(String input);

    @Query("SELECT * FROM dailyWeights WHERE username = :username AND date = :date LIMIT 1")
    public DailyWeight getRecordWithDate(String username, Date date);

    //updates records date and weight for users
    @Query("UPDATE dailyWeights SET weight = :newWeight WHERE username = :username AND date = :date")
    void updateDailyWeight(String username, Date date, double newWeight);

    @Insert(onConflict = OnConflictStrategy.ABORT)
    public void insertDailyWeight(DailyWeight dailyWeight);

    @Update
    public void updateDailyWeight(DailyWeight dailyWeight);
}
