package com.myapplication.ashleysweightdropper.database;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

import com.myapplication.ashleysweightdropper.model.GoalWeight;

import java.util.List;

@Dao
public class GoalWeightDao {
    //Get's a list of GoalWeights from each user
    //One GoalWeight per person
    @Query("SELECT * FROM goalWeight WHERE username = :username ORDER BY id")
    public List<GoalWeight> getAllUserGoalWeights(String username) {
        return null;
    }

    //Reads thw record for current user
    @Query("SELECT * FROM goalWeight WHERE username = :username")
    public GoalWeight getSingleGoalWeight(String username) {
        return null;
    }

    //Updates record for current user
    @Query("UPDATE goalWeight SET goal = :newGoal WHERE username = :username")
    public void updateGoalWeight(double newGoal, String username) {

    }

    //Count records in table
    @Query("SELECT count(*) FROM goalWeight WHERE username = :username")
    public int countGoalEntries(String username) {
        return 0;
    }

    @Insert(onConflict = OnConflictStrategy.ABORT)
    public void insertGoalWeight(GoalWeight goalWeight) {

    }
}
