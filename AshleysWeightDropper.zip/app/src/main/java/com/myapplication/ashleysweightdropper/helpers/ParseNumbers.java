package com.myapplication.ashleysweightdropper.helpers;

//Helps check if string is parsable to int or double
public class ParseNumbers {
    //Checks if sting is parsable to int
    public static boolean isParsableInt(String input) {
        try {
            Integer.parseInt(input);
            return true;
        } catch (final NumberFormatException nfe) {
            return false;
        }
    }
    //Checks if string is parsable to int
    public static boolean isParsableDouble(String input) {
        try {
            Double.parseDouble(input);
            return true;
        } catch (final NumberFormatException nfe) {
            return false;
        }
    }
}
